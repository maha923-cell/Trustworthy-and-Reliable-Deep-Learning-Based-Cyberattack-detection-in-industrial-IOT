from django.apps import AppConfig


class ResearchSiteConfig(AppConfig):
    name = 'Service_Provider'
